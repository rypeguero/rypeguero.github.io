const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

//get /api/trips - return all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({});
        if (!trips) {
            return res.status(404).json({ "message": "trips not found" });
        }
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json(err);
    }
};

// Normalize text values so search and sort comparisons are consistent.
const normalizeText = (value) => {
    return String(value || '').trim().toLowerCase();
};

// Split the search phrase into unique tokens using a Set to remove duplicates.
const tokenizeSearch = (search) => {
    const normalizedSearch = normalizeText(search);

    if (!normalizedSearch) {
        return [];
    }

    return [...new Set(normalizedSearch.split(/\s+/).filter(Boolean))];
};

// Assign a relevance score to each trip based on how strongly it matches the search tokens.
const calculateMatchScore = (trip, tokens) => {
    if (!tokens.length) {
        return 0;
    }

    const code = normalizeText(trip.code);
    const name = normalizeText(trip.name);
    const resort = normalizeText(trip.resort);
    const description = normalizeText(trip.description);
    const details = normalizeText(trip.details);

    let score = 0;

    tokens.forEach((token) => {
        if (code === token) {
            score += 100;
        } else if (code.includes(token)) {
            score += 60;
        }

        if (name === token) {
            score += 90;
        } else if (name.includes(token)) {
            score += 50;
        }

        if (resort.includes(token)) {
            score += 30;
        }

        if (description.includes(token)) {
            score += 20;
        }

        if (details.includes(token)) {
            score += 10;
        }
    });

    return score;
};

// Sort scored trip results by the selected field and use score as a tiebreaker.
const sortTrips = (items, sortBy = 'name', sortOrder = 'asc') => {
    const direction = sortOrder === 'desc' ? -1 : 1;

    const sortValueGetters = {
        name: (trip) => normalizeText(trip.name),
        code: (trip) => normalizeText(trip.code),
        resort: (trip) => normalizeText(trip.resort)
    };

    const getSortValue = sortValueGetters[sortBy] || sortValueGetters.name;

    return [...items].sort((a, b) => {
        const valueA = getSortValue(a.trip);
        const valueB = getSortValue(b.trip);

        if (valueA < valueB) {
            return -1 * direction;
        }

        if (valueA > valueB) {
            return 1 * direction;
        }

        return b.score - a.score;
    });
};

// Paginate the sorted trip results and return metadata for the current page.
const paginateTrips = (items, page = 1, limit = 2) => {
    const safePage = Math.max(parseInt(page, 10) || 1, 1);
    const safeLimit = Math.max(parseInt(limit, 10) || 2, 1);

    const totalTrips = items.length;
    const totalPages = totalTrips === 0 ? 0 : Math.ceil(totalTrips / safeLimit);
    const startIndex = (safePage - 1) * safeLimit;
    const paginatedItems = items.slice(startIndex, startIndex + safeLimit);

    return {
        page: safePage,
        limit: safeLimit,
        totalTrips,
        totalPages,
        items: paginatedItems
    };
};

// Process trip search requests by scoring, sorting, and paginating matching trips.
const tripsSearch = async (req, res) => {
    try {
        const search = req.query.search || '';
        const sortBy = req.query.sortBy || 'name';
        const sortOrder = req.query.sortOrder || 'asc';
        const page = req.query.page || 1;
        const limit = req.query.limit || 2;

        const tokens = tokenizeSearch(search);
        const trips = await Trip.find({}).lean();

        let scoredTrips = trips.map((trip) => ({
            trip,
            score: calculateMatchScore(trip, tokens)
        }));

        if (tokens.length > 0) {
            scoredTrips = scoredTrips.filter((item) => item.score > 0);
        }

        const sortedTrips = sortTrips(scoredTrips, sortBy, sortOrder);
        const paginatedResults = paginateTrips(sortedTrips, page, limit);

        res.status(200).json({
            trips: paginatedResults.items.map((item) => item.trip),
            pagination: {
                page: paginatedResults.page,
                limit: paginatedResults.limit,
                totalTrips: paginatedResults.totalTrips,
                totalPages: paginatedResults.totalPages
            },
            filters: {
                search,
                sortBy,
                sortOrder
            }
        });
    } catch (err) {
        res.status(500).json({
            message: 'Unable to search trips',
            error: err.message
        });
    }
};


//Get api/trips/:tripCode - returns a single trip by code
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.tripCode });
        if (!trip) {
            return res.status(404).json({ "message": "trip not found" });
        }
        res.status(200).json(trip);
    } catch (err) {
        res.status(500).json(err);
    }
};

// POST /api/trips - add a new trip
const tripsAddTrip = async (req, res) => {
    try {
        const trip = await Trip.create({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description,
            details: req.body.details
        });
        res.status(201).json(trip);
    } catch (err) {
        res.status(400).json(err);
    }
};

// PUT /api/trips/:tripCode - update an existing trip
const tripsUpdateTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            {
                code: req.body.code,
                name: req.body.name,
                length: req.body.length,
                start: req.body.start,
                resort: req.body.resort,
                perPerson: req.body.perPerson,
                image: req.body.image,
                description: req.body.description,
                details: req.body.details
            },
            { new: true }
        );
        if (!trip) {
            return res.status(404).json({ "message": "trip not found" });
        }
        res.status(200).json(trip);
    } catch (err) {
        res.status(500).json(err);
    }
};

// DELETE /api/trips/:tripCode - delete a trip
const tripsDeleteTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndDelete({ code: req.params.tripCode });
        if (!trip) {
            return res.status(404).json({ "message": "trip not found" });
        }
        res.status(204).json(null);
    } catch (err) {
        res.status(500).json(err);
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip,
    tripsSearch
};
