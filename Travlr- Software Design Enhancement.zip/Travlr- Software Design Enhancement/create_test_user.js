require('dotenv').config();
require('./app_api/models/db'); // Ensure the database connection is established before creating the user.

// Reuse the shared User model instead of defining a separate schema here.
const mongoose = require('mongoose');
const User = mongoose.model('User');

// Create a predictable admin account for local testing.
const user = new User();
user.name = 'Test Admin';
user.email = 'test@test.com';
user.setPassword('password123');

// Close the shared connection whether the user is created or already exists.
user.save()
    .then(() => {
        console.log('User created: test@test.com / password123');
        mongoose.connection.close();
    })
    .catch(err => {
        if (err.code === 11000) {
            console.log('User already exists: test@test.com / password123');
        } else {
            console.error(err);
        }
        mongoose.connection.close();
    });

