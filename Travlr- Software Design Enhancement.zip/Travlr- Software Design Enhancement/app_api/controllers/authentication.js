const passport = require('passport');
const mongoose = require('mongoose');
const User = mongoose.model('User');

// Register a new user and return a signed JWT on success.
const register = (req, res) => {
    if (!req.body.name || !req.body.email || !req.body.password) {
        return res
            .status(400)
            .json({"message": "All fields required"});
    }

    const user = new User();
    user.name = req.body.name;
    user.email = req.body.email;
    user.setPassword(req.body.password);
    user.save()
        .then(() => {
            const token = user.generateJwt();
            res.status(200)
                .json({token});
        })
        .catch(err => {
            res.status(400)
                .json({
                    message: 'Unable to register user',
                    error: err.message
                });
        });
};

// Authenticate an existing user and return a signed JWT.
const login = (req, res) => {
    if (!req.body.email || !req.body.password) {
        return res
            .status(400)
            .json({"message": "All fields required"});
    }
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return res
                .status(500)
                .json({
                    message: 'Unable to authenticate user',
                    error: err.message
                });
        }
        if (user) {
            const token = user.generateJwt();
            res.status(200)
                .json({token});
        } else {
            res.status(401)
                .json({
                    message: info.message || 'Invalid login credentials'
                });
        }
    })(req, res);
};

module.exports = {
    register,
    login
};
