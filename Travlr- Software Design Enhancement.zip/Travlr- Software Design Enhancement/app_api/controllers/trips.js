const mongoose = require('mongoose');
const Trip = mongoose.model('trips');
const requiredTripFields = [
    "code",
    "name",
    "length",
    "start",
    "resort",
    "perPerson",
    "image",
    "description",
    "details"
];

const validateTripInput = (body) => {
    const errors = [];

    requiredTripFields.forEach((field) => {
        const value = body[field];
        if (value === undefined || value === null || String(value).trim() === '') {
            errors.push(`${field} is required`);
        }
    });

    if (body.start && Number.isNaN(new Date(body.start).getTime())) {
        errors.push("start must be a valid date");
    }

    return errors;

};

const buildTripPayload = (body) => {
    return {
        code: body.code ? body.code.trim() : '',
        name: body.name ? body.name.trim() : '',
        length: body.length ? body.length.trim() : '',
        start: new Date(body.start),
        resort: body.resort ? body.resort.trim() : '',
        perPerson: body.perPerson ? body.perPerson.trim() : '',
        image: body.image ? body.image.trim() : '',
        description: body.description ? body.description.trim() : '',
        details: body.details ? body.details.trim() : ''
    };
};



//get /api/trips - return all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({});
        if (!trips) {
            return res.status(404).json({ "message": "Trips not found" });
        }
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json({
            message: 'Unable to retrieve trips',
            error: err.message
        })
    }
};

//Get api/trips/:tripCode - returns a single trip by code
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.tripCode });
        if (!trip) {
            return res.status(404).json({ "message": "Trip not found" });
        }
        res.status(200).json(trip);
    } catch (err) {
        res.status(500).json({
            message: 'Unable to retrieve trip',
            error: err.message
        })
    }
};

// POST /api/trips - add a new trip
const tripsAddTrip = async (req, res) => {
    const validationErrors = validateTripInput(req.body);
    if (validationErrors.length > 0) {
        return res.status(400).json({ 
            "message": "Invalid trip data", 
            "errors": validationErrors 
        });
    }

    try {
        const trip = await Trip.create(buildTripPayload(req.body));
        res.status(201).json(trip);
    } catch (err) {
        res.status(400).json({
            message: 'Unable to create trip',
            error: err.message
        });
    }
};

// PUT /api/trips/:tripCode - update an existing trip
const tripsUpdateTrip = async (req, res) => {
    const validationErrors = validateTripInput(req.body);
    if (validationErrors.length > 0) {
        return res.status(400).json({ 
            "message": "Invalid trip data", 
            "errors": validationErrors 
        });
    }

    try {
        const trip = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            buildTripPayload(req.body),
            { new: true, runValidators: true }
        );
        if (!trip) {
            return res.status(404).json({ "message": "Trip not found" });
        }
        res.status(200).json(trip);
    } catch (err) {
        res.status(400).json({
            message: 'Unable to update trip',
            error: err.message
        });
    }
};


// DELETE /api/trips/:tripCode - delete a trip
const tripsDeleteTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndDelete({ code: req.params.tripCode });
        if (!trip) {
            return res.status(404).json({ "message": "Trip not found" });
        }
        res.status(204).json(null);
    } catch (err) {
        res.status(500).json({
            message: 'Unable to delete trip',
            error: err.message
        });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};
