const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
};

/* GET travel view */
const travel = async function(req, res, next) {
    try {
        const response = await fetch(tripsEndpoint, options);
        let body = await response.json();
        let message = null;
        
        if (!(body instanceof Array)) {
            message = 'API lookup error';
            body = [];
        } else {
            if (!body.length) {
                message = 'No trips found in database';
            }
        }
        
        res.render('travel', { 
            title: 'Travlr Getaways',
            trips: body,
            message
        });
    } catch (err) {
        res.render('travel', { 
            title: 'Travlr Getaways',
            trips: [],
            message: err.message
        });
    }
};

module.exports = {
    travel
};
