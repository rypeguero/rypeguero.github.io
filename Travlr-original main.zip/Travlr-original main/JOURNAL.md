# CS 465 Full Stack Development: Final Project Journal

## Architecture

In this project, I used two different ways to build the front end of the website. The first way used Express and Handlebars, which is a traditional approach where the server does all the heavy lifting. It builds the entire web page and sends it to the user's browser, which is great for loading the first page quickly, but it means the whole page has to reload every time the user clicks a link. The second way was building a Single-Page Application, or SPA, using Angular. Instead of loading new pages from the server, the SPA loads just one main page at the start. As the user clicks around, JavaScript quietly fetches new data in the background and updates only the parts of the screen that need to change. This makes the website feel much faster and smoother, almost like a mobile app.

For the backend, MongoDB, which is a NoSQL database. Traditional databases use strict tables and rows, kind of like Excel spreadsheets. MongoDB is much more flexible because it stores data in documents that look exactly like JavaScript objects. Since the entire MEAN stack is built on JavaScript, using MongoDB meant I could easily pass data from the database to the server and straight to the user's screen without having to translate it into different formats along the way.

## Functionality

Even though they look similar, JavaScript and JSON do two very different jobs. JavaScript is a programming language that actually does things, like running calculations or updating the screen. JSON, on the other hand, is just a simple text format used to package and transport data. You can think of JSON as the universal translator between the front end and the back end. When the Angular website needs a list of trips, it asks the server. The server gets the trips from the database, packages them up as a JSON text file, and sends them to the browser. The browser then unpacks that JSON back into JavaScript so it can display the trips on the screen.

During the project, I had to refactor, or rewrite, some of my code to make it work better. For example, my original website was just reading trip data from a static, hardcoded file. I refactored the code so that it actually talks to my live database through an API. I also used reusable components when building the Angular site. Instead of writing the code for a "trip card" over and over again, I built it once and reused it everywhere. This saves a lot of time, keeps the code clean, and makes sure the website looks consistent.

## Testing

Testing a full-stack application means making sure the front end and back end are talking to each other correctly. The back end has specific URLs called endpoints, which act like doors to the database. We use different methods to tell the server what we want to do at those doors. For example, a GET method asks the server to hand over data, while a POST method asks the server to save new data. 

Testing these became much more challenging once I added security. I couldn't just send a request to add a new trip anymore. I had to first simulate a user logging in to get a special digital key, called a JSON Web Token. Then, I had to attach that key to my request to prove I was an authorized administrator. This ensures that hackers can't just guess the URL and start deleting or changing the travel packages.

## Reflection

This course has been incredibly helpful for my professional goals because it bridged the gap between learning isolated coding concepts and actually building a real, working application from scratch. I now understand the entire journey of a piece of data, from the moment a user clicks a button on their screen, all the way down to how it gets saved in the database. 

I have developed several valuable skills that make me a much stronger candidate in the software engineering field. I learned how to build a secure API, design flexible databases, and create dynamic, modern user interfaces. Most importantly, I learned how to connect all these different technologies together and troubleshoot the complex bugs that pop up along the way. This experience has given me the confidence to design and build complete web applications on my own.