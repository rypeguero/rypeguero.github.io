require('dotenv').config();
const mongoose = require('mongoose');
const crypto = require('crypto');

// DB Config
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;
mongoose.connect(dbURI);

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    hash: String,
    salt: String
});

// Generate and store a salted password hash for the test user.
userSchema.methods.setPassword = function(password){
    this.salt = crypto.randomBytes(16).toString('hex');
    this.hash = crypto.pbkdf2Sync(password, this.salt,
        1000, 64, 'sha512').toString('hex');
};

const User = mongoose.model('User', userSchema);

const user = new User();
user.name = 'Test Admin';
user.email = 'test@test.com';
user.setPassword('password123');

user.save()
    .then(() => {
        console.log('User created: test@test.com / password123');
        mongoose.disconnect();
    })
    .catch(err => {
        if (err.code === 11000) {
            console.log('User already exists: test@test.com / password123');
        } else {
            console.error(err);
        }
        mongoose.disconnect();
    });
