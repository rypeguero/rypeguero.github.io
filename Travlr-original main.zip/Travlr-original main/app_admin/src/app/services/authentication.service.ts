import { Injectable, Inject } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  // Inject browser storage and the HTTP client used for auth requests.
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private http: HttpClient
  ) { }

  // Retrieve the saved JWT from browser storage.
  public getToken(): string {
    return this.storage.getItem('travlr-token') || '';
  }

  // Persist a JWT so future requests can use the current session.
  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  // Authenticate a user and store the returned JWT.
  public login(user: User): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`/api/login`, user)
      .pipe(
        tap((authResp: AuthResponse) => {
          this.saveToken(authResp.token);
        })
      );
  }

  // Register a new user and store the returned JWT.
  public register(user: User): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`/api/register`, user)
      .pipe(
        tap((authResp: AuthResponse) => {
          this.saveToken(authResp.token);
        })
      );
  }

  // Remove the stored JWT to end the current session.
  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  // Check whether the saved JWT exists and has not expired.
  public isLoggedIn(): boolean {
    const token: string = this.getToken();
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > (Date.now() / 1000);
    } else {
      return false;
    }
  }

  // Decode the saved JWT and return the current user's basic profile data.
  public getCurrentUser(): User | undefined {
    if (this.isLoggedIn()) {
      const token: string = this.getToken();
      const { email, name } = JSON.parse(atob(token.split('.')[1]));
      return { email, name } as User;
    }
    return undefined;
  }
}
