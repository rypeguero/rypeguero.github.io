import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  trip: Trip = {
    _id: '',
    code: '',
    name: '',
    length: '',
    start: new Date(),
    resort: '',
    perPerson: '',
    image: '',
    description: '',
    details: ''
  };
  submitted = false;
  message: string = '';

  // Inject the services needed to create a trip and navigate afterward.
  constructor(
    private tripDataService: TripDataService,
    private router: Router
  ) {}

  // Submit the new trip to the API and return to the listing on success.
  onSubmit(): void {
    this.submitted = true;
    this.tripDataService.addTrip(this.trip).subscribe({
      next: (data) => {
        this.message = 'Trip added successfully!';
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 1500);
      },
      error: (err) => {
        this.message = 'Error adding trip';
        console.error(err);
      }
    });
  }
}
