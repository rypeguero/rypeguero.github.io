import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip implements OnInit {
  trip: Trip = {
    _id: '',
    code: '',
    name: '',
    length: '',
    start: new Date(),
    resort: '',
    perPerson: '',
    image: '',
    description: '',
    details: ''
  };
  tripCode: string = '';
  submitted = false;
  message: string = '';

  // Inject the services needed to load, update, and navigate between trips.
  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  // Load the selected trip when the edit screen is opened.
  ngOnInit(): void {
    this.tripCode = this.route.snapshot.paramMap.get('tripCode') || '';
    if (this.tripCode) {
      this.tripDataService.getTrip(this.tripCode).subscribe({
        next: (trip) => {
          this.trip = trip;
        },
        error: (err) => {
          this.message = 'Error loading trip';
          console.error(err);
        }
      });
    }
  }

  // Submit the updated trip details to the API.
  onSubmit(): void {
    this.submitted = true;
    this.tripDataService.updateTrip(this.tripCode, this.trip).subscribe({
      next: (data) => {
        this.message = 'Trip updated successfully!';
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 1500);
      },
      error: (err) => {
        this.message = 'Error updating trip';
        console.error(err);
      }
    });
  }
}
