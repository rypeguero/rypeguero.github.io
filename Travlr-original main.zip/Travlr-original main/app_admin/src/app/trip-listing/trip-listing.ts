import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { TripCard } from '../trip-card/trip-card';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {
  trips: Trip[] = [];
  message: string = '';

  // Inject services for trip retrieval, navigation, and auth state checks.
  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  // Load trips when the listing component is first displayed.
  ngOnInit(): void {
    this.getTrips();
  }

  // Return whether the current user has an active authenticated session.
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  // Navigate to the add-trip screen.
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  // Retrieve the latest set of trips from the API.
  getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (trips) => {
        this.trips = trips;
        this.message = trips.length > 0 ? '' : 'No trips found';
      },
      error: (err) => {
        this.message = 'Error loading trips';
        console.error(err);
      }
    });
  }

  // Remove a trip after the user confirms the delete action.
  deleteTrip(tripCode: string): void {
    if (confirm('Are you sure you want to delete this trip?')) {
      this.tripDataService.deleteTrip(tripCode).subscribe({
        next: () => {
          this.getTrips();
        },
        error: (err) => {
          this.message = 'Error deleting trip';
          console.error(err);
        }
      });
    }
  }
}
