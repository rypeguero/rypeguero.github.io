import { Routes } from '@angular/router';
import { AddTrip } from './add-trip/add-trip';
import { EditTrip } from './edit-trip/edit-trip';
import { LoginComponent } from './login/login.component';
import { TripListing } from './trip-listing/trip-listing';
import { AuthGuard } from './auth.guard';

export const routes: Routes = [
    { path: 'add-trip', component: AddTrip, canActivate: [AuthGuard] },
    { path: 'edit-trip/:tripCode', component: EditTrip, canActivate: [AuthGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'list-trips', component: TripListing },
    { path: '', component: TripListing, pathMatch: 'full' }
];