import { InjectionToken } from '@angular/core';

export const BROWSER_STORAGE = new InjectionToken<Storage>('Browser Storage', {
  providedIn: 'root',
  // Return browser local storage when available and a safe fallback on the server.
  factory: () => {
    if (typeof localStorage !== 'undefined') {
      return localStorage;
    }
    return null as unknown as Storage; // Return null if on server
  }
});