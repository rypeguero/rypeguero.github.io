import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public formError: string = '';

  public credentials: User = {
    name: '',
    email: '',
    password: ''
  };

  // Inject navigation and authentication services for login flow.
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) { }

  // Initialize the login component state.
  ngOnInit() {
  }

  // Validate the form and start the login request when input is complete.
  public onLoginSubmit(): void {
    this.formError = '';
    if (!this.credentials.email || !this.credentials.password) {
      this.formError = 'All fields are required, please try again';
    } else {
      this.doLogin();
    }
  }

  // Send the credentials to the API and route to the dashboard on success.
  private doLogin(): void {
    this.authenticationService.login(this.credentials)
      .subscribe({
        next: () => this.router.navigateByUrl(''),
        error: (message) => this.formError = message
      });
  }
}
