import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Trip } from '../models/trip';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css',
})
export class TripCard {
  @Input() trip!: Trip;
  @Output() deleteTrip = new EventEmitter<string>();

  // Inject authentication state so actions can be shown conditionally.
  constructor(private authenticationService: AuthenticationService) {}

  // Return whether administrative trip actions should be available.
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  // Emit the selected trip code so the parent component can delete it.
  onDelete(): void {
    this.deleteTrip.emit(this.trip.code);
  }
}
