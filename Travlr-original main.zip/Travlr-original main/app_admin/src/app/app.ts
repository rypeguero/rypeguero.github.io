import { Component } from '@angular/core';
import { RouterOutlet, RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  title = 'Travlr Admin';

  // Inject shared services used by the root application component.
  constructor(
    public authenticationService: AuthenticationService,
    private router: Router
  ) { }

  // Clear the current session and return the user to the login screen.
  public doLogout(): void {
    this.authenticationService.logout();
    this.router.navigateByUrl('/login');
  }
}
