const mongoose = require('mongoose');

// Defining the trip schema
const tripSchema = new mongoose.Schema({
    code: { type: String, required: true, unique: true },
    name: { type: String, required: true, index: true },
    length: { type: String },
    start: { type: Date },
    resort: { type: String },
    perPerson: { type: String },
    image: { type: String, required: true },
    description: { type: String, required: true },
    details: { type: String, required: true }

});

mongoose.model('trips', tripSchema);