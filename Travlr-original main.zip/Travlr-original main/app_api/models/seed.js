const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Bring in the DB connection and Trip model
// We can assume the model is registered if we require the model file directly
// But better to just define valid code here.

// Connect directly
const dbURI = 'mongodb://127.0.0.1/travlr';
mongoose.connect(dbURI);

// Read the model definition
require('./trips'); 
const Trip = mongoose.model('trips');

// Read data from json file
const dataPath = path.join(__dirname, '../../app_server/data/trips.json');
const jsonData = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const trips = jsonData.trips;

// Reset the trips collection and repopulate it from the JSON seed file.
const seedDB = async () => {
    try {
        console.log('Seeding database...');
        
        // Clear existing data
        await Trip.deleteMany({});
        console.log('Cleared existing trips');
        
        // Insert new data
        await Trip.insertMany(trips);
        console.log(`Inserted ${trips.length} trips`);
        
    } catch (err) {
        console.error('Error seeding database:', err);
    } finally {
        mongoose.connection.close();
        console.log('Connection closed');
    }
};

seedDB();
