# Travlr Getaways - Full Stack Web Application

## Project Overview
This project is a full-stack web application developed for **Travlr Getaways**, a travel booking agency. The application allows customers to view available travel packages and provides an administrative interface for staff to manage the trip catalog.

This project was built using the **MEAN stack** (MongoDB, Express.js, Angular, Node.js) as part of the CS 465 Full Stack Development course.

## Architecture
The application consists of three main components:
1. **Customer-Facing Website (Express/Handlebars):** A server-side rendered web application that dynamically displays travel packages to the public.
2. **RESTful API (Node.js/Express/MongoDB):** A secure backend API that handles data storage, retrieval, and user authentication.
3. **Administrative SPA (Angular):** A secure Single Page Application that allows authorized staff to add, edit, and delete travel packages.

## Prerequisites
To run this application locally, you will need:
* [Node.js](https://nodejs.org/) (v18 or higher recommended)
* [Angular CLI](https://angular.io/cli) (`npm install -g @angular/cli`)
* [MongoDB](https://www.mongodb.com/) (Running locally on default port 27017)

## Installation & Setup

### 1. Database Setup
Ensure your local MongoDB server is running. Then, seed the database with initial travel packages and create the test administrator account:

```bash
# From the root directory (travlr)
npm install
node app_api/models/seed.js
node create_test_user.js
```

### 2. Start the Backend Server (API & Customer Site)
The Express server runs the REST API and serves the public-facing Handlebars website.

```bash
# From the root directory (travlr)
npm start
```
* The customer-facing site will be available at: `http://localhost:3000`
* The travel packages page is at: `http://localhost:3000/travel`

### 3. Start the Administrative SPA (Angular)
Open a new terminal window to run the Angular development server.

```bash
# Navigate to the Angular app directory
cd app_admin

# Install Angular dependencies
npm install

# Start the Angular development server
ng serve
```
* The administrative SPA will be available at: `http://localhost:4200`

## Administrative Access
To access the protected administrative features (Add, Edit, Delete trips), use the following test credentials:

* **Email:** `test@test.com`
* **Password:** `password123`

## Security Features
* **JWT Authentication:** The REST API endpoints for modifying data are protected using JSON Web Tokens (JWT).
* **Password Hashing:** User passwords are encrypted using PBKDF2 and salt before being stored in MongoDB.
* **Angular AuthGuard:** Administrative routes in the SPA are protected by an AuthGuard that redirects unauthenticated users to the login page.
* **UI State Management:** Administrative action buttons (Add, Edit, Delete) are hidden from the UI when a user is not logged in.