const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

//get /api/trips - return all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({});
        if (!trips) {
            return res.status(404).json({ "message": "trips not found" });
        }
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json(err);
    }
};

// Normalize text values so search and sort comparisons are consistent.
const normalizeText = (value) => {
    return String(value || '').trim().toLowerCase();
};

// Escape special regex characters so user input is treated as plain search text.
const escapeRegex = (value) => {
    return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};


const requiredTripFields = ['code', 'name', 'image', 'description', 'details'];

// Validate incoming trip data before sending it to MongoDB.
const validateTripInput = (body) => {
    const errors = [];

    requiredTripFields.forEach((field) => {
        const value = body[field];

        if (value === undefined || value === null || String(value).trim() === '') {
            errors.push(`${field} is required`);
        }
    });

    if (body.start && Number.isNaN(new Date(body.start).getTime())) {
        errors.push('start must be a valid date');
    }

    if (body.perPerson !== undefined && body.perPerson !== null && String(body.perPerson).trim() !== '') {
        const parsedPrice = Number(body.perPerson);

        if (Number.isNaN(parsedPrice) || parsedPrice < 0) {
            errors.push('perPerson must be a non-negative number');
        }
    }

    return errors;
};


// Normalize and shape trip data before storing it in the database.
const buildTripPayload = (body) => {
    return {
        code: normalizeText(body.code),
        name: body.name ? body.name.trim() : '',
        length: body.length ? body.length.trim() : undefined,
        start: body.start ? new Date(body.start) : undefined,
        resort: body.resort ? body.resort.trim() : undefined,
        perPerson: body.perPerson !== undefined && body.perPerson !== null && String(body.perPerson).trim() !== '' ? Number(body.perPerson): undefined,
        image: body.image ? body.image.trim() : '',
        description: body.description ? body.description.trim() : '',
        details: body.details ? body.details.trim() : ''
    };
};

// Process trip search requests by filtering, sorting, and paginating trips in MongoDB.
const tripsSearch = async (req, res) => {
    try {
        const search = req.query.search || '';
        const sortBy = ['name', 'code', 'resort'].includes(req.query.sortBy)
            ? req.query.sortBy
            : 'name';
        const sortOrder = req.query.sortOrder === 'desc' ? -1 : 1;
        const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
        const limit = Math.max(parseInt(req.query.limit, 10) || 2, 1);
        const skip = (page - 1) * limit;

        const query = {};

        if (search.trim()) {
            const escapedSearch = escapeRegex(search.trim());
            const searchRegex = new RegExp(escapedSearch, 'i');

            query.$or = [
                { code: searchRegex },
                { name: searchRegex },
                { resort: searchRegex },
                { description: searchRegex },
                { details: searchRegex }
            ];
        }

        const totalTrips = await Trip.countDocuments(query);

        const trips = await Trip.find(query)
            .sort({ [sortBy]: sortOrder })
            .skip(skip)
            .limit(limit)
            .lean();

        const totalPages = totalTrips === 0 ? 0 : Math.ceil(totalTrips / limit);

        res.status(200).json({
            trips,
            pagination: {
                page,
                limit,
                totalTrips,
                totalPages
            },
            filters: {
                search,
                sortBy,
                sortOrder: sortOrder === -1 ? 'desc' : 'asc'
            }
        });
    } catch (err) {
        res.status(500).json({
            message: 'Unable to search trips',
            error: err.message
        });
    }
};

// Summarize stored trip data by resort using MongoDB aggregation.
const tripsSummaryByResort = async (req, res) => {
    try {
        const summary = await Trip.aggregate([
            {
                $match: {
                    resort: { $exists: true, $ne: null, $ne: '' }
                }
            },
            {
                $group: {
                    _id: '$resort',
                    tripCount: { $sum: 1 }
                }
            },
            {
                $project: {
                    _id: 0,
                    resort: '$_id',
                    tripCount: 1
                }
            },
            {
                $sort: { tripCount: -1, resort: 1 }
            }
        ]);

        res.status(200).json(summary);
    } catch (err) {
        res.status(500).json({
            message: 'Unable to summarize trips by resort',
            error: err.message
        });
    }
};


//Get api/trips/:tripCode - returns a single trip by code
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: normalizeText(req.params.tripCode) });
        if (!trip) {
            return res.status(404).json({ "message": "trip not found" });
        }
        res.status(200).json(trip);
    } catch (err) {
        res.status(500).json(err);
    }
};

// POST /api/trips - add a new trip
const tripsAddTrip = async (req, res) => {
    const validationErrors = validateTripInput(req.body);

    if (validationErrors.length > 0) {
        return res.status(400).json({
            message: 'Invalid trip data',
            errors: validationErrors
        });
    }

    try {
        const trip = await Trip.create(buildTripPayload(req.body));
        res.status(201).json(trip);
    } catch (err) {
        if (err.code === 11000) {
            return res.status(409).json({
                message: 'Trip code already exists'
            });
        }

        res.status(400).json({
            message: 'Unable to create trip',
            error: err.message
        });
    }
};

// PUT /api/trips/:tripCode - update an existing trip
const tripsUpdateTrip = async (req, res) => {
    const validationErrors = validateTripInput(req.body);

    if (validationErrors.length > 0) {
        return res.status(400).json({
            message: 'Invalid trip data',
            errors: validationErrors
        });
    }

    try {
        const trip = await Trip.findOneAndUpdate(
            { code: normalizeText(req.params.tripCode) },
            buildTripPayload(req.body),
            {
                new: true,
                runValidators: true,
                context: 'query'
            }
        );

        if (!trip) {
            return res.status(404).json({ message: 'Trip not found' });
        }

        res.status(200).json(trip);
    } catch (err) {
        if (err.code === 11000) {
            return res.status(409).json({
                message: 'Trip code already exists'
            });
        }

        res.status(400).json({
            message: 'Unable to update trip',
            error: err.message
        });
    }
};


// DELETE /api/trips/:tripCode - delete a trip
const tripsDeleteTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndDelete({ code: normalizeText(req.params.tripCode) });
        if (!trip) {
            return res.status(404).json({ "message": "trip not found" });
        }
        res.status(204).json(null);
    } catch (err) {
        res.status(500).json(err);
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip,
    tripsSearch,
    tripsSummaryByResort
};
