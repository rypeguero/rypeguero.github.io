const express = require('express');
const router = express.Router();
const { expressjwt: jwt } = require('express-jwt');
const auth = jwt({
    secret: process.env.JWT_SECRET,
    algorithms: ['HS256'],
    userProperty: 'payload'
});

const authController = require('../controllers/authentication');
const tripsController = require('../controllers/trips');

router
    .route('/login')
    .post(authController.login);

router
    .route('/register')
    .post(authController.register);

// GET /api/trips - return all trips
// POST /api/trips - add a new trip
router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(auth, tripsController.tripsAddTrip);

// GET /api/trips/search - return filtered, sorted, paginated trips
router
    .route('/trips/search')
    .get(tripsController.tripsSearch);

// GET /api/trips/summary/resorts - return a summary of trips by resort
router
    .route('/trips/summary/resorts')
    .get(tripsController.tripsSummaryByResort);

// GET /api/trips/:tripCode - return a single trip by code
// PUT /api/trips/:tripCode - update a trip
// DELETE /api/trips/:tripCode - delete a trip
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(auth, tripsController.tripsUpdateTrip)
    .delete(auth, tripsController.tripsDeleteTrip);

module.exports = router;
