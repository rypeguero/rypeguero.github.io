const mongoose = require('mongoose');

// Defining the trip schema
const tripSchema = new mongoose.Schema({
    code: { type: String, required: true, unique: true, trim: true, lowercase: true, match: /^[a-z0-9_-]+$/ },
    name: { type: String, required: true, index: true, trim: true, minlength: 3 },
    length: { type: String, trim: true },
    start: { type: Date },
    resort: { type: String, trim: true  },
    perPerson: { type: Number, min: 0 },
    image: { type: String, required: true, trim: true },
    description: { type: String, required: true, trim: true, minlength: 15 },
    details: { type: String, required: true, trim: true, minlength: 15 }

}, { timestamps: true });

// Support common trip filtering and sorting patterns with targeted indexes.
tripSchema.index({ resort: 1 });
tripSchema.index({ start: 1 });

// Support keyword-based trip searching across the main descriptive fields.
tripSchema.index({
    name: 'text',
    resort: 'text',
    description: 'text',
    details: 'text'
});

mongoose.model('trips', tripSchema);