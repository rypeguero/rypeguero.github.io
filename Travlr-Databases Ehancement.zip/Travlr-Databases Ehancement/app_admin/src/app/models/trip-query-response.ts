import { Trip } from './trip';

// Describe the structured API response returned by the trip search endpoint.
export interface TripQueryResponse {
  trips: Trip[];
  pagination: {
    page: number;
    limit: number;
    totalTrips: number;
    totalPages: number;
  };
  filters: {
    search: string;
    sortBy: string;
    sortOrder: string;
  };
}
