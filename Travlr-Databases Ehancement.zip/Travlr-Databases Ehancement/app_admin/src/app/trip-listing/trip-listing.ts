import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TripCard } from '../trip-card/trip-card';
import { Trip } from '../models/trip';
import { TripQueryResponse } from '../models/trip-query-response';
import { TripDataService } from '../services/trip-data';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard, FormsModule],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {
  trips: Trip[] = [];
  message: string = '';
  searchTerm: string = '';
  sortBy: string = 'name';
  sortOrder: string = 'asc';
  currentPage: number = 1;
  pageSize: number = 2;
  totalPages: number = 0;
  totalTrips: number = 0;

  // Inject services for trip retrieval, navigation, and auth state checks.
  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  // Load trips when the listing component is first displayed.
  ngOnInit(): void {
    this.loadTrips();
  }

  // Return whether the current user has an active authenticated session.
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  // Navigate to the add-trip screen.
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  // Load filtered, sorted, and paginated trips from the search endpoint.
  loadTrips(): void {
    this.tripDataService
      .searchTrips(this.searchTerm, this.sortBy, this.sortOrder, this.currentPage, this.pageSize)
      .subscribe({
        next: (response: TripQueryResponse) => {
          this.trips = response.trips;
          this.totalPages = response.pagination.totalPages;
          this.totalTrips = response.pagination.totalTrips;
          this.message = response.pagination.totalTrips > 0 ? '' : 'No trips found';
        },
        error: (err) => {
          this.message = 'Error loading trips';
          console.error(err);
        }
    });
  }

  // Reset to the first page and reload trips using the current search and sort settings.
  applyFilters(): void {
    this.currentPage = 1;
    this.loadTrips();
  }

  // Clear the active search and sort settings, then reload the default trip list.
  clearFilters(): void {
    this.searchTerm = '';
    this.sortBy = 'name';
    this.sortOrder = 'asc';
    this.currentPage = 1;
    this.loadTrips();
  }

  // Move to the previous page when one is available.
  goToPreviousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadTrips();
    }
  }

  // Move to the next page when one is available.
  goToNextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.loadTrips();
    }
  }


  // Remove a trip after the user confirms the delete action.
  deleteTrip(tripCode: string): void {
    if (confirm('Are you sure you want to delete this trip?')) {
      this.tripDataService.deleteTrip(tripCode).subscribe({
        next: () => {
          this.loadTrips();
        },
        error: (err) => {
          this.message = 'Error deleting trip';
          console.error(err);
        }
      });
    }
  }
}
