import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { BROWSER_STORAGE } from '../storage';
import { TripQueryResponse } from '../models/trip-query-response';

@Injectable({
  providedIn: 'root',
})
export class TripDataService {
  private apiUrl = '/api/trips';

  // Inject the HTTP client and browser storage used for authenticated requests.
  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  // Send login credentials to the authentication API.
  public login(user: User): Observable<AuthResponse> {
    return this.makeAuthApiCall('login', user);
  }

  // Send registration data to the authentication API.
  public register(user: User): Observable<AuthResponse> {
    return this.makeAuthApiCall('register', user);
  }

  // Build and execute an authentication request for login or registration.
  private makeAuthApiCall(urlPath: string, user: User): Observable<AuthResponse> {
    const url: string = `${this.apiUrl.replace('trips', '')}${urlPath}`;
    return this.http.post<AuthResponse>(url, user);
  }

  // Retrieve all trips from the API.
  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.apiUrl);
  }

  // Retrieve filtered, sorted, and paginated trips from the search endpoint.
  searchTrips(
    search: string,
    sortBy: string,
    sortOrder: string,
    page: number,
    limit: number
  ): Observable<TripQueryResponse> {
    const params = new HttpParams()
      .set('search', search)
      .set('sortBy', sortBy)
      .set('sortOrder', sortOrder)
      .set('page', page)
      .set('limit', limit);

    return this.http.get<TripQueryResponse>(`${this.apiUrl}/search`, { params });
  }


  // Retrieve a single trip by its unique trip code.
  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiUrl}/${tripCode}`);
  }

  // Create a new trip using the authenticated API endpoint.
  addTrip(trip: Trip): Observable<Trip> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${this.storage.getItem('travlr-token')}`
      })
    };
    return this.http.post<Trip>(this.apiUrl, trip, httpOptions);
  }

  // Update an existing trip using the authenticated API endpoint.
  updateTrip(tripCode: string, trip: Trip): Observable<Trip> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${this.storage.getItem('travlr-token')}`
      })
    };
    return this.http.put<Trip>(`${this.apiUrl}/${tripCode}`, trip, httpOptions);
  }

  // Delete a trip using the authenticated API endpoint.
  deleteTrip(tripCode: string): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${this.storage.getItem('travlr-token')}`
      })
    };
    return this.http.delete<void>(`${this.apiUrl}/${tripCode}`, httpOptions);
  }
}
